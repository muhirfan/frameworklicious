//
//  ViewController.swift
//  testARBusinessCard
//
//  Created by Vicky Irwanto on 22/06/23.
// init github

import UIKit
import SceneKit
import ARKit
import SwiftUI
import AVFoundation

class ViewController: UIViewController, ARSCNViewDelegate, ARSessionDelegate {
    
    @IBOutlet var sceneView: ARSCNView!
    var videoPlayer: AVPlayer?
    var lastCapturedAnchors: Set<ARAnchor> = []
    var isImageTracked = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set the view's delegate
        sceneView.delegate = self
        sceneView.session.delegate = self
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // Create a session configuration
        let configuration = ARImageTrackingConfiguration()
        
        
        if let imagesToTrack = ARReferenceImage.referenceImages(inGroupNamed: "AR Resources",
                                                                bundle: Bundle.main) {
            
            configuration.trackingImages = imagesToTrack
            
            // this tells ARKit how many images it is supposed to track simultaneously,
            //ARKit can do upto 100
            configuration.maximumNumberOfTrackedImages = 2
        }
        
        // Run the view's session
        sceneView.session.run(configuration)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        // Pause the view's session
        sceneView.session.pause()
    }
    
    // MARK: - ARSCNViewDelegate
    
    /*
     // Override to create and configure nodes for anchors added to the view's session.
     func renderer(_ renderer: SCNSceneRenderer, nodeFor anchor: ARAnchor) -> SCNNode? {
     let node = SCNNode()
     
     return node
     }
     */
    
    
    func renderer(_ renderer: SCNSceneRenderer, nodeFor anchor: ARAnchor) -> SCNNode? {
        let node = SCNNode()
        
        // Cast the found anchor as image anchor
        guard let imageAnchor = anchor as? ARImageAnchor else { return nil }
        
        // get the name of the image from the anchor
        guard let imageName = imageAnchor.name else { return nil }
       
        
        // Check if the name of the detected image is the one you want
       
        if imageName == "ktm" {
            
            let plane = SCNPlane(width: imageAnchor.referenceImage.physicalSize.width,
                                 height: imageAnchor.referenceImage.physicalSize.height)
            
            let planeNode = SCNNode(geometry: plane)
            
            planeNode.eulerAngles.x = -.pi / 2
            planeNode.opacity = 0.0 // Set initial opacity to 0
            
            createHostingController(for: planeNode)
            // Set initial position to left side of the screen
            let initialPlaneNode1 = SCNVector3(0, -0.01, 0)
            planeNode.position = initialPlaneNode1
            // Disable implicit animations for the opacity property
            SCNTransaction.begin()
            SCNTransaction.animationDuration = 0


            // Animation to move the node from left to right
            let movePlaneNode1 = SCNAction.move(to: SCNVector3(0.5, 0, 0), duration: 0.5)

            // Animation to fade in the opacity
            let fadeInPlaneNode1 = SCNAction.fadeOpacity(to: 1.0, duration: 0.5)

            // Combine move and fade-in animations
            let sequencePlaneNode1 = SCNAction.group([movePlaneNode1, fadeInPlaneNode1])

            // Apply the animation to the planeNode
            planeNode.runAction(sequencePlaneNode1)
            SCNTransaction.commit()
            
            node.addChildNode(planeNode)
            
            let plane2 = SCNPlane(width: imageAnchor.referenceImage.physicalSize.width,
                                 height: imageAnchor.referenceImage.physicalSize.height)
            let planenode2 = SCNNode(geometry: plane2)
            planenode2.eulerAngles.x = -.pi/2
            planenode2.opacity = 0.0
            createHostingControllerForSosmed(for: planenode2)
           
            // Set initial position to left side of the screen
            let initialPlaneNode2 = SCNVector3(0, -0.01, 0.31)
            planenode2.position = initialPlaneNode2
            // Disable implicit animations for the opacity property
            SCNTransaction.begin()
            SCNTransaction.animationDuration = 0

            // Animation to move the node from left to right
            let movePlaneNode2 = SCNAction.move(to: SCNVector3(0, 0, 0.5), duration: 2.0)

            // Animation to fade in the opacity
            let fadeInPlaneNode2 = SCNAction.fadeOpacity(to: 1.0, duration: 2.0)

            // Combine move and fade-in animations
            let sequencePlaneNode2 = SCNAction.group([movePlaneNode2, fadeInPlaneNode2])

            // Apply the animation to the planeNode
            planenode2.runAction(sequencePlaneNode2)
            SCNTransaction.commit()
            node.addChildNode(planenode2)
            
            
            let plane3 = SCNPlane(width: imageAnchor.referenceImage.physicalSize.width,
                                  height: imageAnchor.referenceImage.physicalSize.height)
            let planenode3 = SCNNode(geometry: plane3)
    
            planenode3.eulerAngles.x = -.pi/2
            planenode3.opacity = 0.0
            createHostingControllerForVideo(for: planenode3, imageAnchor: imageAnchor, videoName: "apple-1")
            // Set initial position to left side of the screen
            let initialPlaneNode3 = SCNVector3(0, -0.01, 0)
            planenode3.position = initialPlaneNode3
            // Disable implicit animations for the opacity property
            SCNTransaction.begin()
            SCNTransaction.animationDuration = 0
            // Animation to move the node from left to right
            let movePlaneNode3 = SCNAction.move(to: SCNVector3(0, 0, 0.31), duration: 1.0)

            // Animation to fade in the opacity
            let fadeInPlaneNode3 = SCNAction.fadeOpacity(to: 1.0, duration: 1.0)

            // Combine move and fade-in animations
            let sequencePlaneNode3 = SCNAction.group([movePlaneNode3, fadeInPlaneNode3])

            // Apply the animation to the planeNode
            planenode3.runAction(sequencePlaneNode3)
            SCNTransaction.commit()
            node.addChildNode(planenode3)
            
            let plane4 = SCNPlane(width: imageAnchor.referenceImage.physicalSize.width,
                                 height: imageAnchor.referenceImage.physicalSize.height)
            
            let planeNode4 = SCNNode(geometry: plane4)
            
            planeNode4.eulerAngles.x = -.pi / 2
            planeNode4.opacity = 0.0
            createHostingControllerForBtn(for: planeNode4)
            // Set initial position to left side of the screen
            let initialPlaneNode4 = SCNVector3(0, -0.01, 0.31)
            planeNode4.position = initialPlaneNode4
            // Disable implicit animations for the opacity property
            SCNTransaction.begin()
            SCNTransaction.animationDuration = 0
            // Animation to move the node from left to right
            let movePlaneNode4 = SCNAction.move(to: SCNVector3(0.48, 0, 0.29), duration: 2.0)

            // Animation to fade in the opacity
            let fadeInPlaneNode4 = SCNAction.fadeOpacity(to: 1.0, duration: 2.0)

            // Combine move and fade-in animations
            let sequencePlaneNode4 = SCNAction.group([movePlaneNode4, fadeInPlaneNode4])

            // Apply the animation to the planeNode
            planeNode4.runAction(sequencePlaneNode4)
            SCNTransaction.commit()
            node.addChildNode(planeNode4)
          
            return node
        }else if imageName == "ayu"{
    
            let plane2 = SCNPlane(width: imageAnchor.referenceImage.physicalSize.width,
                                 height: imageAnchor.referenceImage.physicalSize.height)
            let planenode2 = SCNNode(geometry: plane2)
            planenode2.eulerAngles.x = -.pi/2
            planenode2.opacity = 0.0
            createHostingControllerForSosmed(for: planenode2)
           
            // Set initial position to left side of the screen
            let initialPlaneNode2 = SCNVector3(0, -0.01, 0)
            planenode2.position = initialPlaneNode2
            // Disable implicit animations for the opacity property
            SCNTransaction.begin()
            SCNTransaction.animationDuration = 0

            // Animation to move the node from left to right
            let movePlaneNode2 = SCNAction.move(to: SCNVector3(0, 0, 0.2), duration: 2.0)

            // Animation to fade in the opacity
            let fadeInPlaneNode2 = SCNAction.fadeOpacity(to: 1.0, duration: 2.0)

            // Combine move and fade-in animations
            let sequencePlaneNode2 = SCNAction.group([movePlaneNode2, fadeInPlaneNode2])

            // Apply the animation to the planeNode
            planenode2.runAction(sequencePlaneNode2)
            SCNTransaction.commit()
            node.addChildNode(planenode2)
            
            return node
        }
        
        else{
  
            return nil
        }

        
    }
    

    
    func createHostingController(for node: SCNNode) {
        
        
        // Do this on the main thread
        DispatchQueue.main.async {
            // create a hosting controller with SwiftUI view
            let arVC = UIHostingController(rootView: SwiftUIARCardView())
            arVC.willMove(toParent: self)
            // make the hosting VC a child to the main view controller
            self.addChild(arVC)
            
            // set the pixel size of the Card View
            arVC.view.frame = CGRect(x: 0, y: 0, width: 500, height: 350)
            
            
            // add the ar card view as a subview to the main view
            self.view.addSubview(arVC.view)
            
            
            // render the view on the plane geometry as a material
            self.show(hostingVC: arVC, on: node)
        }
    }
    
    func show(hostingVC: UIHostingController<SwiftUIARCardView>, on node: SCNNode) {
        // create a new material
        let material = SCNMaterial()
        
        // this allows the card to render transparent parts the right way
        hostingVC.view.isOpaque = false
        
        // set the diffuse of the material to the view of the Hosting View Controller
        material.diffuse.contents = hostingVC.view
        
        // Set the material to the geometry of the node (plane geometry)
        node.geometry?.materials = [material]
        
        hostingVC.view.backgroundColor = UIColor.clear
    }
    
    func createHostingControllerForSosmed(for node: SCNNode) {
        
        
        // Do this on the main thread
        DispatchQueue.main.async {
            // create a hosting controller with SwiftUI view
            let arVC = UIHostingController(rootView: SocialMediaView())
            arVC.willMove(toParent: self)
            // make the hosting VC a child to the main view controller
            self.addChild(arVC)
            
            // set the pixel size of the Card View
            arVC.view.frame = CGRect(x: 0, y: 0, width: 500, height: 350)
            
            
            // add the ar card view as a subview to the main view
            self.view.addSubview(arVC.view)
            
            
            // render the view on the plane geometry as a material
            self.showSosmed(hostingVC: arVC, on: node)
        }
    }
    
    func showSosmed(hostingVC: UIHostingController<SocialMediaView>, on node: SCNNode) {
        // create a new material
        let material = SCNMaterial()
        
        // this allows the card to render transparent parts the right way
        hostingVC.view.isOpaque = false
        
        // set the diffuse of the material to the view of the Hosting View Controller
        material.diffuse.contents = hostingVC.view
        
        // Set the material to the geometry of the node (plane geometry)
        node.geometry?.materials = [material]
        
        hostingVC.view.backgroundColor = UIColor.clear
    }
    
    func createHostingControllerForVideo(for node: SCNNode, imageAnchor: ARImageAnchor, videoName: String) {
        
        guard let videoURL = Bundle.main.url(forResource: "\(videoName)", withExtension: "mp4") else {
                        print("Failed to find video file")
                        return
                    }

                    videoPlayer = AVPlayer(url: videoURL)
                    videoPlayer?.play()
        
                    

                    let videoScene = SKScene(size: CGSize(width: 640, height: 480))
                let videoNode = SKVideoNode(avPlayer: videoPlayer!)
                    videoNode.position = CGPoint(x: videoScene.size.width / 2, y: videoScene.size.height / 2)
                    videoNode.size = videoScene.size
                    videoNode.yScale = -1.0 // Invert the video vertically
                    videoScene.addChild(videoNode)

                    if let plane = node.geometry as? SCNPlane {
                        let spriteKitPlane = SCNPlane(width: plane.width, height: plane.height)
                        spriteKitPlane.firstMaterial?.diffuse.contents = videoScene
                        spriteKitPlane.firstMaterial?.isDoubleSided = true

                        let spriteKitNode = SCNNode(geometry: spriteKitPlane)

                        node.addChildNode(spriteKitNode)
                    } else {
                
                        print("Failed to create hosting controller for video")
                    }
            
            
        
       
    }
    
    
    func createHostingControllerForBtn(for node: SCNNode) {
        
        
        // Do this on the main thread
        DispatchQueue.main.async {
            // create a hosting controller with SwiftUI view
            let arVC = UIHostingController(rootView: ButtonView())
            arVC.willMove(toParent: self)
            // make the hosting VC a child to the main view controller
            self.addChild(arVC)
            
            // set the pixel size of the Card View
            arVC.view.frame = CGRect(x: 0, y: 0, width: 500, height: 350)
            
            
            // add the ar card view as a subview to the main view
            self.view.addSubview(arVC.view)
            
            
            // render the view on the plane geometry as a material
            self.showBtn(hostingVC: arVC, on: node)
        }
    }
    
    func showBtn(hostingVC: UIHostingController<ButtonView>, on node: SCNNode) {
        // create a new material
        let material = SCNMaterial()
        
        // this allows the card to render transparent parts the right way
        hostingVC.view.isOpaque = false
        
        // set the diffuse of the material to the view of the Hosting View Controller
        material.diffuse.contents = hostingVC.view
        
        // Set the material to the geometry of the node (plane geometry)
        node.geometry?.materials = [material]
        
        hostingVC.view.backgroundColor = UIColor.clear
    }
    
    
    
    func session(_ session: ARSession, didUpdate anchors: [ARAnchor]) {
        // Present an error message to the user
        if let imageAnchor = anchors.compactMap({ $0 as? ARImageAnchor }).first(where: { $0.name == "ktm" }) {
               // Image anchor is found, play the video
               videoPlayer?.play()
           } else {
               // Image anchor is not found, pause the video
               
               videoPlayer?.pause()
              
           }
        
    
    }
    
    func sessionWasInterrupted(_ session: ARSession) {
        // Inform the user that the session has been interrupted, for example, by presenting an overlay
        
    }
    
    func sessionInterruptionEnded(_ session: ARSession) {
        // Reset tracking and/or remove existing anchors if consistent tracking is required
        
    }
}

//
//  SwiftUICardView.swift
//  testARBusinessCard
//
//  Created by Vicky Irwanto on 22/06/23.
//

import SwiftUI

struct SwiftUIARCardView: View {
   
    var body: some View {
        HStack(spacing: 20){
            ZStack{
                Image("profile")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .clipShape(Circle())
                   
            }
    

            Text("Vicky\nIrwanto")
                .font(.system(size: 42, weight: .bold, design: .monospaced))
        }
        .preferredColorScheme(.dark)
    }
}

struct SwiftUIARCardView_Previews: PreviewProvider {
    static var previews: some View {
        SwiftUIARCardView()
    }
}

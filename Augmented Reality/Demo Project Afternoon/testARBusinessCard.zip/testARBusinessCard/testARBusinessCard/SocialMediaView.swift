//
//  SocialMediaView.swift
//  testARBusinessCard
//
//  Created by Vicky Irwanto on 28/06/23.
//

import SwiftUI

struct SocialMediaView: View {
    var body: some View {
        HStack(spacing: 30){
            Button(action: {
                
            }, label: {
                ZStack{
                    Circle()
                        .foregroundColor(.white)
                    Image(systemName: "message.fill")
                        .resizable()
                        .frame(width: 35, height: 35)
                        .foregroundColor(.black)
                        
                }
            })
            
            Button(action: {
                
            }, label: {
                ZStack{
                    Circle()
                        .foregroundColor(.white)
                    Image(systemName: "phone.fill")
                        .resizable()
                        .frame(width: 35, height: 35)
                        .foregroundColor(.black)
                        
                }
            })
            
            Button(action: {
                
            }, label: {
                ZStack{
                    Circle()
                        .foregroundColor(.white)
                    Image(systemName: "video.fill")
                        .resizable()
                        .frame(width: 35, height: 20)
                        .foregroundColor(.black)
                        
                }
            })
            
            Button(action: {
                
            }, label: {
                ZStack{
                    Circle()
                        .foregroundColor(.white)
        
                    Image(systemName: "envelope.fill")
                        .resizable()
                        .frame(width: 35, height: 25)
                        .foregroundColor(.black)
                        
                }
            })
            
        }
        .preferredColorScheme(.dark)
    }
}

struct SocialMediaView_Previews: PreviewProvider {
    static var previews: some View {
        SocialMediaView()
    }
}

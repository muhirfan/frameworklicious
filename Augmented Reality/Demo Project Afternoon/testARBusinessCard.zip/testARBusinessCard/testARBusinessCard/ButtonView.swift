//
//  ButtonView.swift
//  testARBusinessCard
//
//  Created by Vicky Irwanto on 28/06/23.
//

import SwiftUI

struct ButtonView: View {
    var body: some View {
        VStack{
            Button(action: {
                
            }, label: {
                ZStack{
                    RoundedRectangle(cornerRadius: 15)
                        .frame(width: 300, height: 75)
                        .foregroundColor(.white)
                    HStack{
                        Image("linkedin")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 50, height: 50)
                        Text("Linkedin/in/vickyir")
                            .font(.system(size: 18, weight: .bold, design: .monospaced))
                            .foregroundColor(.black)
                    }
                    
                }
                
            })
            
            Button(action: {
                
            }, label: {
                ZStack{
                    RoundedRectangle(cornerRadius: 15)
                        .frame(width: 300, height: 75)
                        .foregroundColor(.white)
                    HStack{
                        Image("ig")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 50, height: 50)
                        Text("intagram/vickyir523")
                            .font(.system(size: 18, weight: .bold, design: .monospaced))
                            .foregroundColor(.black)
                    }
                   
                }
               
            })
        }
        .preferredColorScheme(.dark)
    }
}

struct ButtonView_Previews: PreviewProvider {
    static var previews: some View {
        ButtonView()
    }
}
